<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Crud extends Model
{
    protected $table = "files";
    protected $primaryKey = "id";
    public $timestamps = false;
    protected $fillable = [
     'file_name', 'file_location', 'uploader_id'
    ];
}
