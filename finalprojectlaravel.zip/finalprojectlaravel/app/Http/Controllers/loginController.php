<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class loginController extends Controller
{
   public function index(Request $req){
    	
    	//return view('login.index');

         
         $user = DB::table('students')->where('email', $req->email)
            ->where('password', $req->password)
            ->first();

    	if($user){
            $req->session()->put('uname', $req->email);
    		return redirect()->route('admin.index');
    	}else{

            $req->session()->flash('msg', "Invalid username/password");
    		return redirect('/index');
            //return view('login.index');
    	}

    }

     public function profile(Request $request){
        $uploader_id=$request->session()->get('uname');
        $acc = DB::table('students')->where('email',$uploader_id)
            ->first();
        return view('login.profile')->with('user', $acc);
    }
}
