<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Crud;

class crudController extends Controller
{
    public function index(){

    	return view('login.upload');
    }

    public function action(){

    	$acc = Crud::all();

    	return view('login.action')->with('files', $acc);
    }

    public function store(Request $request){

    	$uploader_id=$request->session()->get('uname');
    	
    	if($request->hasFile('pic')){

    		$file = $request->file('pic');
    		$file->move('upload/', $file->getClientOriginalName());

    		$form_data = array(
            'file_name'         =>   $request->filename,
            'file_location'     =>   $file->getClientOriginalName(),
            'uploader_id'         =>  $uploader_id
            
        );
        Crud::create($form_data);
        return redirect()->route('file.create');

    	}else{
    		echo "Error !!";
    	}
    }

     public function edit($addid){
    	$acc = Crud::find($addid);
    	return view('login.edit')->with('data', $acc);
    }

     public function update(Request $request, $accId){


    	$uploader_id=$request->session()->get('uname');
    	
    	if($request->hasFile('pic')){

    		$file = $request->file('pic');
    		$file->move('upload/', $file->getClientOriginalName());

    		$form_data = array(
            'file_name'         =>   $request->filename,
            'file_location'     =>   $file->getClientOriginalName(),
            'uploader_id'         =>  $uploader_id
            
        );
        Crud::whereId($accId)->update($form_data);
        return redirect()->route('action.view');

    	}else{
    		echo "Error !!";
    	}

    }

       public function destroy($accId){
        $acc = Crud::destroy($accId);
        return redirect()->route('action.view');
    }
   

}
