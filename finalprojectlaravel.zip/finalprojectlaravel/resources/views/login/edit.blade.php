
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Project management</title>
    
    <!-- Bootstrap Core CSS -->
    <link href="{{'admin'}}/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="{{'admin'}}/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="{{'admin'}}/dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="{{'admin'}}/vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="{{'admin'}}/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
    	* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 50%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: left;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 15px;
}

.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
    </style>

</head>

<body>

    <div id="wrapper">

        
        </nav>

        <div id="page-wrapper">
           
            <!-- /.row -->
            
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i>Student file create
                            
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                           <div class="container">
                      <form method="post" enctype="multipart/form-data">
                         <div class="row">
                     <div class="col-25">
                      <label for="file">File Name</label>
                       </div>
                      <div class="col-75">
                      <input type="text" id="fname" name="filename" placeholder="File name" value="{{$data['file_name']}}">
                       </div>
                       </div>
                        <div class="row">
                         <div class="col-25">
                       <label for="file">Select a Txt file</label>
                           </div>
                       <div class="col-75">
                           <input type="file" name="pic" value="{{$data['file_location']}}"><br><br>
                         </div>
                       </div>
                      <div class="row">
                      <input type="submit" value="Submit">
                           </div>
                      </form>
                        </div>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                    
                         
                    
                </div>
                <!-- /.col-lg-8 -->
                <div class="col-lg-4">
                    
                </div>
                   
                    </div>
                    <!-- /.panel .chat-panel -->
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>
       

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="{{'admin'}}/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="{{'admin'}}/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="{{'admin'}}/vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="{{'admin'}}/vendor/raphael/raphael.min.js"></script>
    <script src="{{'admin'}}/vendor/morrisjs/morris.min.js"></script>
    <script src="{{'admin'}}/data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="{{'admin'}}/dist/js/sb-admin-2.js"></script>

</body>

</html>

