<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/index', 'indexController@index')->name('home.index');
Route::post('/index', 'loginController@index');
Route::get('/logout', 'logoutController@index')->name('logout.index');

Route::group(['middleware'=>['sess']], function(){
Route::get('/login', 'adminController@index')->name('admin.index');
Route::get('/login/action', 'adminController@action')->name('live_search.action');
Route::get('/filecreate', 'crudController@index')->name('file.create');
Route::post('/filecreate', 'crudController@store');
Route::get('/action', 'crudController@action')->name('action.view');
Route::get('/profile', 'loginController@profile')->name('action.profile');
Route::get('/action/{addid}/edit', 'crudController@edit')->name('action.edit');
Route::post('/action/{addid}/edit', 'crudController@update');
Route::get('/action/{addid}/delete', 'crudController@destroy')->name('action.destroy');
});